package com.joshuamccall.StartApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprimberjBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprimberjBackendApplication.class, args);
	}
}
